package com.application.sit305_task21p;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Spinner sourceSpinner, destinationSpinner;
    private EditText valueInput;
    private TextView resultOutput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sourceSpinner = findViewById(R.id.source_spinner);
        destinationSpinner = findViewById(R.id.destination_spinner);
        valueInput = findViewById(R.id.value_input);
        resultOutput = findViewById(R.id.result_output);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
            R.array.length_units, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sourceSpinner.setAdapter(adapter);
        destinationSpinner.setAdapter(adapter);

        Button convertButton = findViewById(R.id.convert_button);
        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertUnits();
            }
        });
    }
    private void convertUnits() {
        String sourceUnit = sourceSpinner.getSelectedItem().toString();
        String destinationUnit = destinationSpinner.getSelectedItem().toString();
        double value = Double.parseDouble(valueInput.getText().toString());

        double result = UnitConverter.convert(value, sourceUnit, destinationUnit);
        resultOutput.setText(String.valueOf(result));
    }
    public static class UnitConverter {
        public static double convert(double value, String sourceUnit, String destinationUnit) {
            // Length conversions
            if (sourceUnit.equals("Inches") && destinationUnit.equals("Centimeters")) {
                return value * 2.54;
            } else if (sourceUnit.equals("Feet") && destinationUnit.equals("Centimeters")) {
                return value * 30.48;
            } else if (sourceUnit.equals("Yards") && destinationUnit.equals("Centimeters")) {
                return value * 91.44;
            } else if (sourceUnit.equals("Miles") && destinationUnit.equals("Kilometers")) {
                return value * 1.60934;
            }
            // Weight conversions
            else if (sourceUnit.equals("Pounds") && destinationUnit.equals("Kilograms")) {
                return value * 0.453592;
            } else if (sourceUnit.equals("Ounces") && destinationUnit.equals("Grams")) {
                return value * 28.3495;
            } else if (sourceUnit.equals("Tonnes") && destinationUnit.equals("Kilograms")) {
                return value * 907.185;
            }
            // Temperature conversions
            else if (sourceUnit.equals("Celsius") && destinationUnit.equals("Fahrenheit")) {
                return (value * 1.8) + 32;
            } else if (sourceUnit.equals("Fahrenheit") && destinationUnit.equals("Celsius")) {
                return (value - 32) / 1.8;
            } else if (sourceUnit.equals("Celsius") && destinationUnit.equals("Kelvin")) {
                return value + 273.15;
            } else if (sourceUnit.equals("Kelvin") && destinationUnit.equals("Celsius")) {
                return value - 273.15;
            }
            // If no conversion is supported, this will return the original value
            return value;
        }
    }
}
